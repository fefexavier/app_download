package com.example.file_upload_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
